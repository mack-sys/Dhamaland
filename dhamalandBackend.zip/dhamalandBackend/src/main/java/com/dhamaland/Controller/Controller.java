package com.dhamaland.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dhamaland.DaoImpl.StudentRegistrationService;
import com.dhamaland.Modal.StudentRegistration;

@RestController
@CrossOrigin(value = "*")
public class Controller {
	
	@Autowired
	StudentRegistrationService studentService;
	
	@PostMapping("/registration")
	private int saveStudentRegistrationForm(@RequestBody StudentRegistration student) {
		studentService.saveStudentRegistration(student);
		return student.getId();
	}
	
	@GetMapping("/registration-list")
	private List<StudentRegistration> getStudentRegistrationList(){
		return studentService.getAllStudentRegistrationList();
	}
	
	@DeleteMapping("/registration/{id}")
	private void deleteRegistration(@PathVariable("id") int id) {
		studentService.deleteStudentRegistration(id);
	}
	
	@GetMapping("/registration-id/{id}")
	private List<StudentRegistration> getStudentById(@PathVariable("id") int id){
		return studentService.getStudentRegistrationById(id);
	}
	
	@GetMapping("registration-obj/{id}")
	private StudentRegistration getOneRegistration(@PathVariable("id") int id) {
		return studentService.oneRegistration(id);
	}
	
	@GetMapping("/totalRegistor")
	private Long totalRegistor() {
		return studentService.totalStudentRegistor();
	}
}
