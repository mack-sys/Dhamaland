package com.dhamaland.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dhamaland.DaoImpl.BlogDaoImpl;
import com.dhamaland.Modal.Blog;

@RestController
@CrossOrigin(value = "*")
public class BlogController {
	@Autowired BlogDaoImpl service;
	
	
	@PostMapping("/save-blog")
	private void saveBlogController(@RequestBody Blog blog) {
		service.saveBlog(blog);
		System.out.println(blog.getId());
	}
	
	@GetMapping("/view-blog")
	private List<Blog> blogList(){
		return service.viewAllBlogList();
	}
	
	@DeleteMapping("/delete-blog/{id}")
	private void deleteBlogById(@PathVariable("id") int id) {
		service.deletBlog(id);
	}
}
