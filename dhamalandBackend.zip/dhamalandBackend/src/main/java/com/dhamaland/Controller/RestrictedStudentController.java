package com.dhamaland.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhamaland.DaoImpl.RestrictedStudentDaoImpl;
import com.dhamaland.Modal.RestrictedStudent;
import com.dhamaland.Modal.StudentRegistration;

@RestController
@CrossOrigin(value = "*")
public class RestrictedStudentController {

	@Autowired RestrictedStudentDaoImpl restrictService;

	
	@GetMapping("/restricted-one/{id}")
	private StudentRegistration getStudentRestrictId(@PathVariable("id") int id){
		return restrictService.saveStudentRestricted(id);
	}
	
	@GetMapping("/restricted-list")
	private List<RestrictedStudent> getAllRestrictedStudent(){
		return restrictService.getAllBlockStudent();
	}
	
	@DeleteMapping("/restrict-delete/{id}")
	private void deleteRegistration(@PathVariable("id") int id) {
		restrictService.deleteStudentRestricted(id);
	}
	
	
	
	
}
