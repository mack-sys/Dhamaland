package com.dhamaland.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.dhamaland.DaoImpl.FreeCourseDaoImpl;

@Controller
@CrossOrigin(value = "*")


public class FreeCoursesController {
	@Autowired FreeCourseDaoImpl service;
	
	@GetMapping("/save-free-course/{id}/{course}")
	public void saveFreeCourse(@PathVariable("id") int id,@PathVariable("course") String course) {
		service.saveFreeCourse(id, course);
			System.out.println("freeCourseSave");
	}
}
