package com.dhamaland.Dao;

public interface FreeCoursesDao {
	
	public void saveFreeCourse(int id,String courseName);
}
