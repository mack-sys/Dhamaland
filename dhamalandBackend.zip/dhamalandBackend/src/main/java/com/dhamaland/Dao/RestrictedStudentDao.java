package com.dhamaland.Dao;

import java.util.List;

import com.dhamaland.Modal.RestrictedStudent;
import com.dhamaland.Modal.StudentRegistration;



public interface RestrictedStudentDao {

	public StudentRegistration saveStudentRestricted(int id);
	
	public List<RestrictedStudent> getAllBlockStudent();
	
	public void deleteStudentRestricted(int id);
	
}
