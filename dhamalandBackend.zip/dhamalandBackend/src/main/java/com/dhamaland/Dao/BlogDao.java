package com.dhamaland.Dao;

import java.util.List;

import com.dhamaland.Modal.Blog;

public interface BlogDao {
	public void saveBlog(Blog blog);
	
	public List<Blog> viewAllBlogList();
	
	public void deletBlog(int id);
}
