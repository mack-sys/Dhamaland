package com.dhamaland.Dao;

import java.util.List;

import com.dhamaland.Modal.StudentRegistration;



public interface StudentRegistrationDao {

	public void saveStudentRegistration(StudentRegistration registration);
	
	public List<StudentRegistration> getAllStudentRegistrationList();
	
	public void deleteStudentRegistration(int id);
	
	public List<StudentRegistration> getStudentRegistrationById(int id);
	
	public StudentRegistration oneRegistration(int id);
	
	public Long totalStudentRegistor();
}
