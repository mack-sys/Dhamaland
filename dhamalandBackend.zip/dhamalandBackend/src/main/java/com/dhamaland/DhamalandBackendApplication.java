package com.dhamaland;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DhamalandBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DhamalandBackendApplication.class, args);
	}

}
