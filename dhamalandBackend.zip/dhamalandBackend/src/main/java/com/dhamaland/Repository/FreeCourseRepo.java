package com.dhamaland.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dhamaland.Modal.FreeCourse;

@Repository
public interface FreeCourseRepo extends CrudRepository<FreeCourse, Integer> {

}
