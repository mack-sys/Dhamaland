package com.dhamaland.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dhamaland.Modal.StudentRegistration;

@Repository
public interface StudentRegistrationRepository extends CrudRepository<StudentRegistration, Integer>{

}
