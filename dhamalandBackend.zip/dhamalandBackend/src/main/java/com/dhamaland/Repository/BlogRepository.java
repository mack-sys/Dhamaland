package com.dhamaland.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dhamaland.Modal.Blog;

@Repository
public interface BlogRepository extends CrudRepository<Blog, Integer> {

}
