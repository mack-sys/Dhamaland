package com.dhamaland.DaoImpl;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhamaland.Dao.StudentRegistrationDao;
import com.dhamaland.Modal.StudentRegistration;
import com.dhamaland.Repository.StudentRegistrationRepository;

@Service
public class StudentRegistrationService implements StudentRegistrationDao{
	
	@Autowired
	StudentRegistrationRepository repo;
	
	@Override
	public void saveStudentRegistration(StudentRegistration registration) {
		// TODO Auto-generated method stub
		
		repo.save(registration);
		System.out.println("Student Registration saved");
		
	}

	@Override
	public List<StudentRegistration> getAllStudentRegistrationList() {
		// TODO Auto-generated method stub
		List<StudentRegistration> list = new ArrayList<StudentRegistration>();
		repo.findAll().forEach(reg -> list.add(reg));
		
		return list;
	}

	@Override
	public void deleteStudentRegistration(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
		
	}

	@Override
	public List<StudentRegistration> getStudentRegistrationById(int id) {
		// TODO Auto-generated method stub
		List<StudentRegistration> list = new ArrayList<StudentRegistration>();
		list.add(repo.findById(id).get()) ;
				
		return list;
	}

	@Override
	public StudentRegistration oneRegistration(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
		
	}

	@Override
	public Long totalStudentRegistor() {
		// TODO Auto-generated method stub
		System.out.println(repo.count());
		return repo.count();
	}

}
