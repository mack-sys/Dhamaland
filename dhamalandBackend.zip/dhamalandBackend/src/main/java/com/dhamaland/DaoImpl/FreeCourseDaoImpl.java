package com.dhamaland.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhamaland.Dao.FreeCoursesDao;
import com.dhamaland.Modal.FreeCourse;
import com.dhamaland.Modal.StudentRegistration;
import com.dhamaland.Repository.FreeCourseRepo;

@Service
public class FreeCourseDaoImpl implements FreeCoursesDao{

	@Autowired FreeCourseRepo repo;
	@Autowired StudentRegistrationService service;
	
	@Override
	public void saveFreeCourse(int id, String courseName) {
		// TODO Auto-generated method stub
		StudentRegistration st = service.oneRegistration(id);
		FreeCourse fs = new FreeCourse();
		
		fs.setFirstName(st.getFirstName());
		fs.setLastName(st.getFirstName());
		fs.setAddress(st.getAddress());
		fs.setEmail(st.getEmail());
		fs.setPassword(st.getPassword());
		fs.setPhoneNumber(st.getPhoneNumber());
		fs.setCity(st.getCity());
		fs.setState(st.getState());
		fs.setPostalCode(st.getPostalCode());
		fs.setCourseName(courseName);
		repo.save(fs);
		
		
	}

}
