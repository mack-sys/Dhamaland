package com.dhamaland.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhamaland.Dao.RestrictedStudentDao;
import com.dhamaland.Modal.RestrictedStudent;
import com.dhamaland.Modal.StudentRegistration;
import com.dhamaland.Repository.RestrictedStudentRepository;

@Service
public class RestrictedStudentDaoImpl implements RestrictedStudentDao {

	@Autowired
	RestrictedStudentRepository repo;
	
	@Autowired
	StudentRegistrationService service;
	
	@Override
	public StudentRegistration saveStudentRestricted(int id) {
		// TODO Auto-generated method stub
		List<RestrictedStudent> list = new ArrayList<RestrictedStudent>();
		StudentRegistration st = service.oneRegistration(id);
		RestrictedStudent st1 = new RestrictedStudent();
		st1.setId(st.getId());
		st1.setFirstName(st.getFirstName());
		st1.setLastName(st.getLastName());
		st1.setEmail(st.getEmail());
		st1.setPhoneNumber(st.getPhoneNumber());
		st1.setPassword(st.getPassword());
		st1.setCity(st.getCity());
		st1.setState(st.getCity());
		st1.setPostalCode(st.getPostalCode());
		st1.setAddress(st.getAddress());
		
		repo.save(st1);
		System.out.println(st1);
		return st;
		
		
	}

	@Override
	public List<RestrictedStudent> getAllBlockStudent() {
		// TODO Auto-generated method stub
		List<RestrictedStudent> list = new ArrayList<RestrictedStudent>();
		repo.findAll().forEach(e-> list.add(e));
		
		return list;
	}

	@Override
	public void deleteStudentRestricted(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

}
