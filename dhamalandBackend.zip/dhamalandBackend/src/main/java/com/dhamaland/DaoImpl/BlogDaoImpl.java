package com.dhamaland.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhamaland.Dao.BlogDao;
import com.dhamaland.Modal.Blog;
import com.dhamaland.Repository.BlogRepository;

@Service
public class BlogDaoImpl implements BlogDao{
	
	@Autowired BlogRepository repo;
	
	@Override
	public void saveBlog(Blog blog) {
		// TODO Auto-generated method stub
		repo.save(blog);
		
	}

	@Override
	public List<Blog> viewAllBlogList() {
		// TODO Auto-generated method stub
		List<Blog> list = new ArrayList<Blog>();
		repo.findAll().forEach(e -> list.add(e));
		return list;
	}

	@Override
	public void deletBlog(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

}
