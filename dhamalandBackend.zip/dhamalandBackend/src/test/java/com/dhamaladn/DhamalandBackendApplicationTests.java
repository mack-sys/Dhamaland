package com.dhamaladn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhamalandBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
