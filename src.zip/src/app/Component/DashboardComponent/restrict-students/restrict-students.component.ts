import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restrict-students',
  templateUrl: './restrict-students.component.html',
  styleUrls: ['./restrict-students.component.css']
})
export class RestrictStudentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
