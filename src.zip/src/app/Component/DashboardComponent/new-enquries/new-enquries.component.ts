import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-enquries',
  templateUrl: './new-enquries.component.html',
  styleUrls: ['./new-enquries.component.css']
})
export class NewEnquriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
