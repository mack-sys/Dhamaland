import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booklets',
  templateUrl: './booklets.component.html',
  styleUrls: ['./booklets.component.css']
})
export class BookletsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
