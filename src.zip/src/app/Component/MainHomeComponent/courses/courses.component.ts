import { Component, OnInit } from '@angular/core';
import { StudentRegistrationServiceService } from '../../../Backend/Service/student-registration-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  constructor(private service : StudentRegistrationServiceService,private route:Router) { }

  getAllStudentRegistration : any;
  ngOnInit(): void {
    this.service.getAllRegistration().subscribe(data=>{
      this.getAllStudentRegistration = data;
      console.log(this.getAllStudentRegistration);
      
    })
  }

  enrolled:boolean =false;
  courseName1 = "Basic Pali"
  courseName2 = "Pali speaking"
  courseName3 = "Buddhist Psychotherapyg"
  courseName4 = "Meditation (Mind-cultivation)"

  
  enrolledNow(){
  
    
    this.route.navigate(['/student-login'])

    let id = this.service.regId;
    console.log(id);
    console.log(this.courseName1);
    if(this.service.setLogin == true){
      this.service.addFreeCourse(id,"Basic Pali").subscribe(data=>{
        console.log(data);
        
      })

    }
 
  }
  enrolledNow1(){
   
  }
  enrolledNow2(){
   
  }
  enrolledNow3(){
  
  }

 
}
