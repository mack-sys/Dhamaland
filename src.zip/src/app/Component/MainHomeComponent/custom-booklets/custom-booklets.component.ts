import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-booklets',
  templateUrl: './custom-booklets.component.html',
  styleUrls: ['./custom-booklets.component.css']
})
export class CustomBookletsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
