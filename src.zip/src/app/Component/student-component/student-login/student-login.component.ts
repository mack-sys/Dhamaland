import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentRegistrationServiceService } from '../../../Backend/Service/student-registration-service.service';

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit {

  login = this.fb.group({
    email: [null,Validators.required],
    password :[null,Validators.required]
  })
  constructor(private fb:FormBuilder,private  studentService:StudentRegistrationServiceService,private route:Router) { }

  
  studentData : any;
  passwordNotMatch: boolean = false;
  emailNotMatch:boolean = false;


  ngOnInit(): void {
    this.studentService.getAllRegistration().subscribe(data =>{
      this.studentData = data
      console.log(this.studentData);
      
    })
  }
  onSubmit(){
    console.log(this.login.value);

    if(this.login.value.email == null && this.login.value.password == null){
      alert("form empty")
    }
    else {
      for(let data of this.studentData){
          if(data.email == this.login.value.email && data.password == this.login.value.password){
          this.passwordNotMatch = true;
          this.studentService.list = data.email;
          this.studentService.stName = data.firstName;
          this.studentService.regId = data.id;
          this.studentService.setLogin = true;
          console.log(data.id);
  
          this.route.navigate(['/student-profile'])
          console.log("login");
         }
    
        if(data.email == this.login.value.email){
          this.emailNotMatch = true;
        }
     
      }
      if(this.emailNotMatch == false && this.passwordNotMatch == false){
        alert("Email and password not matched")
       }
        else if(this.emailNotMatch == false){

        alert("Email not match")
       }
       else if(this.passwordNotMatch == false)
       {
          alert("Password not matched")
       }
       
    }


    
  }
}
