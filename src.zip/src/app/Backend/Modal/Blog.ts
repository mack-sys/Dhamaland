export class Blog{
    id?:number;
    heading :any
    content:any
    date: any
}