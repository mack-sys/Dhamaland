export class StudentRegistration {
    id?:number;
    firstName:any
    lastName:any
    email:any
    password:any
    address:any
    phoneNumber:any
    city:any
    state:any
    postalCode:any

  
}
